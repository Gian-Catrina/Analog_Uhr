# Analog Clock
Welcome to my GitHub Repository :D. Here's how i made a Analog Clock using Java-Script, CSS and HTML. Alltough i have to say, that the HTML file is not a file that i created or modified.

## Java-Script
On the Java-Script code i used this 2 References:
* For querySelector i used: https://www.w3schools.com/jsref/met_document_queryselector.asp

* For now.getTime i used: https://www.w3schools.com/jsref/jsref_getHours.asp

Also the Java-Script file only has the function to make the hands work. 

## CSS
On the CSS code i used this Reference:
*  For vmin i used: https://www.w3schools.com/cssref/css_units.php

The CSS file contains the designs and elements. Also the background fade is made in the CSS.

## HTML

The HTML code isnt written by me as i already said. It is written by @retofroelicher. Also the HTML file is only there to combine the Java-Script and CSS file. And se
  

